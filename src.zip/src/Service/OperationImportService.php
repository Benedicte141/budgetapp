<?php
use Doctrine\Common\Collections\ArrayCollection;
    
class OperationImportService implements OperationImportInterface{
    private BankApiRepository $bankApiRep;
    private BankApi $bankApiInstance;
    private ArrayCollection $bankApiFieldMapping;
    private ArrayCollection $importErrors;

    public function __construct()
    {
        $this->bankApiRep = $doctrine->getRepository(BankApi::class);
        $this->importErrors = [];
    }
    
    
    
    
    /**
    * Importe les opérations d'un compte bancaire depuis une API bancaire
    * @param int $bankApiId id de l'API bancaire
    * @param array $options options pour configurer l'importation (e.g., période)
    */
    public function importOperations(int $bankApiId, array $options = []): void{
        $this->bankApiInstance = $bankApiRep->find($bankApiId);
        $this->bankApiFieldMapping = $this->bankApiInstance.getFieldMapping();
    }



    /**
    * Parse une opération bancaire depuis l'API bancaire en utilisant le mapping de champs défini dans fieldMapping
    * @param array $operationArray tableau associatif de l'opération bancaire
    * @return ?Operation retourne une opération ou null si le parsing échoue
    */
    public function parseOperation(array $operationArray): ?Operation{

        if (array_keys($array1) == array_keys($array2)) {
            foreach ($this->bankApiFieldMapping as $key => $value) {
                if($this->bankApiRep->findOneBy(['external_id' => $operationArray[array_search('external_id', $this->bankApiFieldMapping )]])){
                    $this->importErrors.push("l'operation "+$operationArray['name']+" existe déjà");
                }
                else{
                    $operation = new Operation();
                    $operation->setMontant($operationArray[array_search('montant', $this->bankApiFieldMapping )]);
                    $operation->setLibelle($operationArray[array_search('libelle', $this->bankApiFieldMapping )]);
                    $operation->setDate($operationArray[array_search('date', $this->bankApiFieldMapping )]);
                    $operation->setExternalId($operationArray[array_search('external_id', $this->bankApiFieldMapping )]);
            
                    $this->entityManager->persist($operation);
                    $this->entityManager->flush();
                }

            }
        }else{
            $this->importErrors.push("l'operation "+$operationArray['name']+" n'a pas les clés valides. Soit elles ne sont pas toutes présentes, soit elles ne sont pas correctes");
            return null;
        }
        
    }
    /**
    * Vérifie la validité des champs d'une opération
    * @param Operation $operation
    * @return bool
    */


    public function validateOperation(Operation $operation): bool{
        
    }
    /**
    * Retourne uniquement les opérations valides qui n'existent pas déjà dans la base de données (avec externalId)
    * @param Operation[] $normalizedOperations tableau associatif des opérations bancaires
    * @return Operation[] tableau des opérations non dupliquées
    */



    public function checkDuplicates(array $normalizedOperations): array{
        
    }
    /**
    * Retourne la liste des erreurs d'importation avec leur contexte
    * @return array<array{error: ImportationError, operation: ?Operation}>
    */



    public function getImportationErrors(): array{
        
    }
    /**
    * Retourne les opérations importées lors de la dernière importation
    * @return Operation[]
    */


    
    public function getOperations(): array{
        
    }
}
